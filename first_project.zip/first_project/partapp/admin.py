from django.contrib import admin
from .models import *

admin.site.register(Busrwa)

# @admin.register(Busrwa)

# class adminModel(admin.ModelAdmin):
    
#         list_display = ('__all__') 
    #   search_field = ("Bus")  
    # class Meta:
    #     model = 'book' 
 

# Register your models here.
