from django.shortcuts import render,redirect
from .forms import busForm
from .models import Busrwa
from django.http import HttpResponse
# from django.shortcuts import get_object_or_404
# from django.http import JsonResponse

def alex(request):
    return render(request,'bike.html')


def ticket(request):
    if request.method == 'POST':
        form = busForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('alex')
    else:
        form = busForm()
    return render(request, 'form.html', {'form': form})

def select(request):
    tick=Busrwa.objects.all()
    return render(request,'list.html',{'tick':tick})
    
def serv(request):
    return render(request,'service.html')  

def visit(request):
    return render(request,'visit.html')
    return redirect(feedback)
def feedback(request):
    return render(request,'feedback.html')
def about(request):
    return render(request,'about.html')

def delete(request,id):
    obj=Busrwa.objects.get(id=id)
    obj.delete()
    return ('select')
#     
