from django.urls import path
from .views import *
from django.urls import path


urlpatterns = [
    path('',alex,name='alex'),
    path('v/',ticket,name='ticket'),
    path('select/',select,name='select'),
    path('serv/',serv,name='serv'),
    path('visit/',visit,name='visit'),
    path('about/',about,name='about'),  
]