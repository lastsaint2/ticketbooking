from django import forms
from.models import Busrwa

class busForm(forms.ModelForm):
    class Meta:
            model=Busrwa
            fields=('__all__')
    
