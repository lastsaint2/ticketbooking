from django.apps import AppConfig


class PartappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'partapp'
