from django.db import models
from django.utils import timezone



class Busrwa(models.Model):
    
    fname=models.CharField(max_length=50,null=False,blank=False)
    lname=models.CharField(max_length=50,null=False,blank=False)
    email=models.CharField( max_length=50,null=False,blank=False)
    location=models.CharField( max_length=50,null=False,blank=False)
    pay=models.CharField(max_length=50,null=False,blank=False,default=0,)
    date=models.DateTimeField(auto_now=False, auto_now_add=False, default=timezone.now)
    def  __str__(self):
        return f"{self.fname}-{self.lname}-{self.email}-{self.location}-{self.pay}-{self.date}" 


